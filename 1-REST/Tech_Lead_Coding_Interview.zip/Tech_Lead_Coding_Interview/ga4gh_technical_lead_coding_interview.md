# Coding Interview [GA4GH Technical Lead]

In this assessment, we would like you to check the compliance of the DRS Starter Kit's *GET /objects/{object_id}* endpoint to the DRS v1.2.0 specification. This can be done by deploying a DRS Starter Kit on your local machine and writing tests to check the compliance of *GET /objects/{object_id}* endpoint.

For this exercise, we are only interested in the *GET /objects/{object_id}* endpoint and the DRS Starter Kit does not enforce any authorization. 

## Background and useful resources:

- **Data Repository Service (DRS) v1.2.0**: https://ga4gh.github.io/data-repository-service-schemas/preview/release/drs-1.2.0/docs/
- **GA4GH Starter Kit DRS website:** https://starterkit.ga4gh.org/docs/starter-kit-apis/drs/drs_overview
- **GA4GH Starter Kit DRS Github:** https://github.com/ga4gh/ga4gh-starter-kit-drs

## 1. Deploy a GA4GH Starter Kit DRS on your local machine
 
Follow the instructions in *DRS_Starter_Kit/README.md* file to deploy the DRS Starter Kit and populate it with test DRS objects.

## 2. Write tests to check the following 

Send a `GET` Request to `http://localhost:5000/ga4gh/drs/v1/objects/{object_id}` endpoint with the below listed input DRS object Ids and verify that the outputs are as expected

|object_id | Expected Status Code | Expected Content Type |
| -------- | -------------------- | --------------------- |
|8e18bfb64168994489bc9e7fda0acd4f  | 200 | JSON |
|ecbb0b5131051c41f1c302287c13495c  | 200 | JSON |
|xx18bfb64168994489bc9e7fda0acd4f  | 404 | JSON |


## 3. Please add any other tests that you would carry out to confirm that the "/objects/{object_id}" endpoint follows  DRS v1.2 specification

If you are not able to add these tests to your code, please note these down on your README document.

## 4. Submission

Please add your code to a public Github repository along with a production quality README document describing your repository, installations, usage and next steps.